export type Student = {
  id: string;
  name: string;
  rfid: string;
  email: string;
  points: number;
  avatar: string;
};

export type Bin = {
  id: string;
  name: string;
  location: string;
  fillLevel: number; // 0-100
  status: 'Good' | 'Needs Attention' | 'Full';
};

export type Disposal = {
  id: string;
  studentId: string;
  studentName: string;
  studentAvatar: string;
  binId: string;
  binName: string;
  timestamp: Date;
  points: number;
};

export type Alert = {
  id: string;
  binId: string;
  binName: string;
  message: string;
  timestamp: Date;
  acknowledged: boolean;
};

export type Reward = {
  id: string;
  name: string;
  points: number;
  qrCodeUrl: string;
};

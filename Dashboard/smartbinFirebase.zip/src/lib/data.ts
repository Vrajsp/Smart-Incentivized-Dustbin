import type { Student, Bin, Disposal, Alert, Reward } from './types';
import { placeholderImages } from './placeholder-images.json';

// Mock Students
export const students: Student[] = [
  { id: '1', name: 'Aarav Sharma', rfid: '2210001', email: '2210001@ritindia.edu', points: 1250, avatar: placeholderImages[0].imageUrl },
  { id: '2', name: 'Diya Patel', rfid: '2210002', email: '2210002@ritindia.edu', points: 1100, avatar: placeholderImages[1].imageUrl },
  { id: '3', name: 'Vivaan Gupta', rfid: '2210003', email: '2210003@ritindia.edu', points: 980, avatar: placeholderImages[2].imageUrl },
  { id: '4', name: 'Ananya Singh', rfid: '2210004', email: '2210004@ritindia.edu', points: 950, avatar: placeholderImages[3].imageUrl },
  { id: '5', name: 'Ishaan Kumar', rfid: '2210005', email: '2210005@ritindia.edu', points: 820, avatar: placeholderImages[4].imageUrl },
  { id: '6', name: 'Myra Reddy', rfid: '2210006', email: '2210006@ritindia.edu', points: 750, avatar: placeholderImages[5].imageUrl },
  { id: '7', name: 'Kabir Joshi', rfid: '2210007', email: '2210007@ritindia.edu', points: 680, avatar: placeholderImages[6].imageUrl },
  { id: '8', name: 'Saanvi Rao', rfid: '2210008', email: '2210008@ritindia.edu', points: 610, avatar: placeholderImages[7].imageUrl },
  { id: '9', name: 'Arjun Desai', rfid: '2210009', email: '2210009@ritindia.edu', points: 540, avatar: placeholderImages[8].imageUrl },
  { id: '10', name: 'Zara Khan', rfid: '2210010', email: '2210010@ritindia.edu', points: 490, avatar: placeholderImages[9].imageUrl },
];

// Mock Bins
export const bins: Bin[] = [
  { id: 'bin-01', name: 'Main Canteen Bin', location: 'Near Canteen', fillLevel: 45, status: 'Good' },
  { id: 'bin-02', name: 'Library Entrance Bin', location: 'Library', fillLevel: 75, status: 'Needs Attention' },
  { id: 'bin-03', name: 'Hostel A Block', location: 'Hostel A', fillLevel: 92, status: 'Full' },
  { id: 'bin-04', name: 'Workshop Bin', location: 'Workshop', fillLevel: 20, status: 'Good' },
  { id: 'bin-05', name: 'Sports Complex', location: 'Sports Ground', fillLevel: 60, status: 'Needs Attention' },
  { id: 'bin-06', name: 'Admin Building', location: 'Admin Office', fillLevel: 15, status: 'Good' },
];

// Mock Disposals
export const disposals: Disposal[] = [
  { id: 'd-1', studentId: '1', studentName: 'Aarav Sharma', studentAvatar: placeholderImages[0].imageUrl, binId: 'bin-01', binName: 'Main Canteen Bin', timestamp: new Date(Date.now() - 1 * 60 * 1000), points: 10 },
  { id: 'd-2', studentId: '4', studentName: 'Ananya Singh', studentAvatar: placeholderImages[3].imageUrl, binId: 'bin-02', binName: 'Library Entrance Bin', timestamp: new Date(Date.now() - 3 * 60 * 1000), points: 10 },
  { id: 'd-3', studentId: '5', studentName: 'Ishaan Kumar', studentAvatar: placeholderImages[4].imageUrl, binId: 'bin-01', binName: 'Main Canteen Bin', timestamp: new Date(Date.now() - 5 * 60 * 1000), points: 10 },
  { id: 'd-4', studentId: '2', studentName: 'Diya Patel', studentAvatar: placeholderImages[1].imageUrl, binId: 'bin-05', binName: 'Sports Complex', timestamp: new Date(Date.now() - 8 * 60 * 1000), points: 15 },
  { id: 'd-5', studentId: '3', studentName: 'Vivaan Gupta', studentAvatar: placeholderImages[2].imageUrl, binId: 'bin-03', binName: 'Hostel A Block', timestamp: new Date(Date.now() - 12 * 60 * 1000), points: 5 },
];

// Mock Alerts
export const alerts: Alert[] = [
  { id: 'alert-1', binId: 'bin-03', binName: 'Hostel A Block', message: 'Bin is over 90% full. Please arrange for collection.', timestamp: new Date(Date.now() - 2 * 60 * 1000), acknowledged: false },
  { id: 'alert-2', binId: 'bin-02', binName: 'Library Entrance Bin', message: 'Bin fill level reached 75%. Needs attention soon.', timestamp: new Date(Date.now() - 30 * 60 * 1000), acknowledged: true },
];

// Mock Rewards
export const rewards: Reward[] = [
    { id: 'r-1', name: 'Free Coffee Coupon', points: 500, qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=REWARD-COFFEE-01' },
    { id: 'r-2', name: 'Bookstore Voucher (₹100)', points: 1000, qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=REWARD-BOOK-02' },
    { id: 'r-3', name: 'Campus T-Shirt', points: 2000, qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=REWARD-TSHIRT-03' },
    { id: 'r-4', name: 'Canteen Meal Pass', points: 750, qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=REWARD-MEAL-04' },
];

// Aggregated Data
export const totalPoints = students.reduce((sum, student) => sum + student.points, 0);
export const totalDisposals = 1342; // A static number for mock

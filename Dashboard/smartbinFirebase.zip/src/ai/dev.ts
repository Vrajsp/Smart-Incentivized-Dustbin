import { config } from 'dotenv';
config();

import '@/ai/flows/bin-fill-suggestion.ts';
'use server';

/**
 * @fileOverview A bin fill suggestion AI agent.
 *
 * - binFillSuggestion - A function that suggests how to optimally distribute waste across bins.
 * - BinFillSuggestionInput - The input type for the binFillSuggestion function.
 * - BinFillSuggestionOutput - The return type for the binFillSuggestion function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const BinFillSuggestionInputSchema = z.object({
  binLevels: z
    .array(z.number())
    .describe('An array of numbers representing the current fill level (0-100) of each bin.'),
  campusMap: z
    .string()
    .optional()
    .describe('Optional description of the campus layout to help with bin distribution suggestions.'),
});
export type BinFillSuggestionInput = z.infer<typeof BinFillSuggestionInputSchema>;

const BinFillSuggestionOutputSchema = z.object({
  suggestion: z.string().describe('A detailed suggestion on how to distribute waste optimally across the bins.'),
});
export type BinFillSuggestionOutput = z.infer<typeof BinFillSuggestionOutputSchema>;

export async function binFillSuggestion(input: BinFillSuggestionInput): Promise<BinFillSuggestionOutput> {
  return binFillSuggestionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'binFillSuggestionPrompt',
  input: {schema: BinFillSuggestionInputSchema},
  output: {schema: BinFillSuggestionOutputSchema},
  prompt: `You are an AI assistant that helps campus administrators manage waste collection efficiently.

You are given the current fill levels of the bins on campus and an optional description of the campus layout.

Based on this information, you should provide a detailed suggestion on how to distribute waste optimally across the bins to prevent overflowing.

Current Bin Fill Levels: {{{binLevels}}}
Campus Map Description: {{{campusMap}}}

Suggestion:`,
});

const binFillSuggestionFlow = ai.defineFlow(
  {
    name: 'binFillSuggestionFlow',
    inputSchema: BinFillSuggestionInputSchema,
    outputSchema: BinFillSuggestionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

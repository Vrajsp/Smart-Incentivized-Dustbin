
import {
  bins,
  students,
  disposals,
  alerts,
  rewards,
  totalPoints,
  totalDisposals,
} from '@/lib/data';
import { StatCard } from '@/components/dashboard/stat-card';
import {
  Users,
  Trash2,
  Trophy,
  Lightbulb,
} from 'lucide-react';
import { BinStatusGrid } from '@/components/dashboard/bin-status-grid';
import { AiSuggestionCard } from '@/components/dashboard/ai-suggestion-card';
import { Leaderboard } from '@/components/dashboard/leaderboard';
import { DisposalFeed } from '@/components/dashboard/disposal-feed';
import { AlertsPanel } from '@/components/dashboard/alerts-panel';
import { RewardsSection } from '@/components/dashboard/rewards-section';

export default function DashboardPage() {
  return (
    <div className="grid gap-6 grid-cols-1 lg:grid-cols-4 xl:grid-cols-5">
      <div className="lg:col-span-4 xl:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Students"
          value={students.length}
          icon={Users}
        />
        <StatCard
          title="Total Disposals"
          value={totalDisposals}
          icon={Trash2}
        />
        <StatCard
          title="Total Points Earned"
          value={totalPoints}
          icon={Trophy}
        />
        <StatCard
          title="AI Suggestions"
          value="Ready"
          icon={Lightbulb}
        />
      </div>

      <div className="lg:col-span-4 xl:col-span-3">
        <BinStatusGrid bins={bins} />
      </div>

      <div className="lg:col-span-4 xl:col-span-2">
        <AiSuggestionCard bins={bins} />
      </div>
      
      <div className="lg:col-span-2 xl:col-span-3">
        <Leaderboard students={students} />
      </div>

      <div className="lg:col-span-2 xl:col-span-2">
        <DisposalFeed disposals={disposals} />
      </div>

      <div className="lg:col-span-4 xl:col-span-5">
        <AlertsPanel alerts={alerts} />
      </div>
      
      <div className="lg:col-span-4 xl:col-span-5">
        <RewardsSection rewards={rewards} />
      </div>
    </div>
  );
}

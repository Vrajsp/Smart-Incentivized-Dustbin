
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

export default function Home() {
  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
      <Card className="w-full max-w-lg text-center">
        <CardHeader>
          <CardTitle className="text-3xl font-bold">Welcome to SmartBin</CardTitle>
          <CardDescription>
            The intelligent solution for waste management on campus.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-6 text-muted-foreground">
            Navigate to the dashboard to see real-time data, manage bins, and view student leaderboards.
          </p>
          <Link href="/dashboard">
            <Button size="lg">
              Go to Dashboard <ArrowRight className="ml-2" />
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}

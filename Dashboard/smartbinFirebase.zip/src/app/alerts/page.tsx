
import { AlertsPanel } from '@/components/dashboard/alerts-panel';
import { alerts } from '@/lib/data';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function AlertsPage() {
  return (
    <div className="space-y-6">
       <Card>
        <CardHeader>
            <CardTitle className="text-3xl">Alerts</CardTitle>
            <CardDescription>
                View and manage all system-generated alerts for the bin network.
            </CardDescription>
        </CardHeader>
      </Card>
      <AlertsPanel alerts={alerts} />
    </div>
  );
}

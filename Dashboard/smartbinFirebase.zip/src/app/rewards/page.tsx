
import { RewardsSection } from '@/components/dashboard/rewards-section';
import { rewards } from '@/lib/data';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function RewardsPage() {
  return (
    <div className="space-y-6">
        <Card>
            <CardHeader>
                <CardTitle className="text-3xl">Rewards</CardTitle>
                <CardDescription>
                Manage and view available rewards for students.
                </CardDescription>
            </CardHeader>
        </Card>
      <RewardsSection rewards={rewards} />
    </div>
  );
}

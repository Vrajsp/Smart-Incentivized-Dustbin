
"use client";

import { Sidebar, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarHeader, SidebarFooter, SidebarContent } from "@/components/ui/sidebar";
import { SmartBinLogo } from "@/components/icons";
import { Home, LayoutGrid, Users, BarChart3, Bell, Award } from "lucide-react";
import Link from 'next/link';
import { usePathname } from 'next/navigation';

export function AppSidebar() {
    const pathname = usePathname();

    const menuItems = [
        { href: "/", label: "Home", icon: Home },
        { href: "/dashboard", label: "Dashboard", icon: LayoutGrid },
        { href: "/leaderboard", label: "Leaderboard", icon: BarChart3 },
        { href: "/students", label: "Students", icon: Users },
        { href: "/alerts", label: "Alerts", icon: Bell, badge: "2" },
        { href: "/rewards", label: "Rewards", icon: Award },
    ];

    return (
      <Sidebar side="left" collapsible="icon" variant="sidebar">
        <SidebarHeader>
          <Link href="/" className="flex items-center gap-2 p-2">
            <SmartBinLogo className="w-8 h-8 text-primary" />
            <span className="text-lg font-semibold">SmartBin</span>
          </Link>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            {menuItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <Link href={item.href} passHref>
                  <SidebarMenuButton tooltip={item.label} isActive={pathname === item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                    {item.badge && <span className="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-destructive text-destructive-foreground text-xs">{item.badge}</span>}
                  </SidebarMenuButton>
                </Link>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter>
            {/* Can add user profile or settings link here */}
        </SidebarFooter>
      </Sidebar>
    );
  }

import type { SVGProps } from "react";

export function SmartBinLogo(props: SVGProps<SVGSVGElement>) {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        {...props}
      >
        <path d="M10 5.04l.28.28A2 2 0 0 0 11.69 6h.62a2 2 0 0 1 1.41.59L14 7" />
        <path d="M5.33 10H18.5a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H5.5a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2Z" />
        <path d="M4 10V7a2 2 0 0 1 2-2h2" />
        <path d="M15 14h.01" />
        <path d="M11 14h.01" />
        <path d="M7 14h.01" />
      </svg>
    );
  }
  
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import type { Reward } from '@/lib/types';
import Image from 'next/image';

export function RewardsSection({ rewards }: { rewards: Reward[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>QR & Rewards</CardTitle>
        <CardDescription>
          Students can scan these QR codes to redeem their rewards.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Carousel
          opts={{
            align: 'start',
            loop: true,
          }}
          className="w-full"
        >
          <CarouselContent>
            {rewards.map((reward) => (
              <CarouselItem key={reward.id} className="md:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                <div className="p-1">
                  <Card className="text-center">
                    <CardHeader>
                        <CardTitle className="text-base">{reward.name}</CardTitle>
                        <CardDescription>{reward.points.toLocaleString()} points</CardDescription>
                    </CardHeader>
                    <CardContent className="flex aspect-square items-center justify-center p-6">
                      <Image
                        src={reward.qrCodeUrl}
                        alt={`QR code for ${reward.name}`}
                        width={150}
                        height={150}
                        className="rounded-lg"
                        data-ai-hint="qr code"
                      />
                    </CardContent>
                  </Card>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="hidden sm:flex" />
          <CarouselNext className="hidden sm:flex" />
        </Carousel>
      </CardContent>
    </Card>
  );
}

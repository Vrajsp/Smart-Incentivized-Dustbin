import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
  } from '@/components/ui/card';
  import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
  } from '@/components/ui/table';
  import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
  import type { Student } from '@/lib/types';
  import { Trophy } from 'lucide-react';
  
  export function Leaderboard({ students }: { students: Student[] }) {
    const sortedStudents = [...students].sort((a, b) => b.points - a.points);
  
    const getRankColor = (rank: number) => {
        if (rank === 1) return "text-yellow-400";
        if (rank === 2) return "text-gray-400";
        if (rank === 3) return "text-yellow-600";
        return "text-muted-foreground";
    }

    return (
      <Card>
        <CardHeader>
          <CardTitle>Top Students</CardTitle>
          <CardDescription>
            Leaderboard of students with the most points.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]">Rank</TableHead>
                <TableHead>Student</TableHead>
                <TableHead className="text-right">Points</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedStudents.slice(0, 5).map((student, index) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">
                    <div className="flex justify-center items-center">
                        {index < 3 ? <Trophy className={`w-5 h-5 ${getRankColor(index + 1)}`} /> : index + 1}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={student.avatar} alt={student.name} data-ai-hint="student avatar" />
                        <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{student.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {student.email}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-semibold text-primary">{student.points.toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    );
  }
  
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Bin } from '@/lib/types';
import { BinFillChart } from './bin-fill-chart';
import { MapPin } from 'lucide-react';

export function BinStatusGrid({ bins }: { bins: Bin[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Bin Network Status</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-3 gap-6">
        {bins.map((bin) => (
          <div key={bin.id} className="flex flex-col items-center gap-2">
            <BinFillChart fillLevel={bin.fillLevel} />
            <div className="text-center">
              <p className="font-semibold text-sm">{bin.name}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                {bin.location}
              </p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

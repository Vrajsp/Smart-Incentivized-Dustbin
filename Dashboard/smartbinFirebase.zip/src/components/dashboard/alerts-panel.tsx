'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import type { Alert } from '@/lib/types';
import { AlertTriangle, CheckCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useState } from 'react';

export function AlertsPanel({ alerts: initialAlerts }: { alerts: Alert[] }) {
    const [alerts, setAlerts] = useState(initialAlerts);

    const handleAcknowledge = (alertId: string) => {
        setAlerts(alerts.map(a => a.id === alertId ? {...a, acknowledged: true} : a));
    }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alerts & Notifications</CardTitle>
        <CardDescription>Automated alerts for bins requiring attention.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className={`flex items-start gap-4 p-4 rounded-lg ${
              alert.acknowledged
                ? 'bg-secondary'
                : 'bg-destructive/10 dark:bg-destructive/20'
            }`}
          >
            {alert.acknowledged ? (
                <CheckCircle className="h-5 w-5 mt-1 text-green-500" />
            ) : (
                <AlertTriangle className="h-5 w-5 mt-1 text-destructive" />
            )}
            
            <div className="flex-1">
              <p className="font-medium">
                {alert.binName} -{' '}
                <span className="font-normal text-muted-foreground">
                  {alert.message}
                </span>
              </p>
              <p className="text-xs text-muted-foreground">
                {formatDistanceToNow(alert.timestamp, { addSuffix: true })}
              </p>
            </div>
            {!alert.acknowledged && (
              <Button size="sm" onClick={() => handleAcknowledge(alert.id)}>Acknowledge</Button>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

'use client';

import * as React from 'react';
import {
  RadialBar,
  RadialBarChart,
  PolarAngleAxis,
  ResponsiveContainer,
} from 'recharts';

import { cn } from '@/lib/utils';
import { useTheme } from 'next-themes';

interface BinFillChartProps {
  fillLevel: number;
}

export function BinFillChart({ fillLevel }: BinFillChartProps) {
  const [animatedLevel, setAnimatedLevel] = React.useState(0);
  const { theme } = useTheme();

  React.useEffect(() => {
    const timeout = setTimeout(() => setAnimatedLevel(fillLevel), 100);
    return () => clearTimeout(timeout);
  }, [fillLevel]);

  const color =
    animatedLevel > 80
      ? 'hsl(var(--destructive))'
      : animatedLevel > 50
      ? 'hsl(var(--warning))'
      : 'hsl(var(--primary))';

  const data = [{ name: 'fill', value: animatedLevel, fill: color }];

  const circleSize = 120;

  return (
    <div className="relative flex h-32 w-32 items-center justify-center">
      <ResponsiveContainer width="100%" height="100%">
        <RadialBarChart
          innerRadius="75%"
          outerRadius="90%"
          barSize={10}
          data={data}
          startAngle={90}
          endAngle={-270}
        >
          <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
          <RadialBar
            background={{ fill: 'hsl(var(--muted))' }}
            dataKey="value"
            cornerRadius={10}
            angleAxisId={0}
          />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span
          className="text-3xl font-bold"
          style={{ color }}
        >
          {Math.round(animatedLevel)}%
        </span>
        <span className="text-xs text-muted-foreground">Filled</span>
      </div>
    </div>
  );
}

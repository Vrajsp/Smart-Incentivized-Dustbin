import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
  } from '@/components/ui/card';
  import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
  import type { Disposal } from '@/lib/types';
  import { formatDistanceToNow } from 'date-fns';
  
  export function DisposalFeed({ disposals }: { disposals: Disposal[] }) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Real-Time Feed</CardTitle>
          <CardDescription>Live log of recent disposals.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {disposals.map((disposal) => (
            <div key={disposal.id} className="flex items-center gap-3">
              <Avatar className="h-9 w-9">
                <AvatarImage src={disposal.studentAvatar} alt={disposal.studentName} data-ai-hint="student avatar"/>
                <AvatarFallback>{disposal.studentName.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 text-sm">
                <p>
                  <span className="font-medium">{disposal.studentName}</span>{' '}
                  disposed in{' '}
                  <span className="font-medium">{disposal.binName}</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(disposal.timestamp, { addSuffix: true })}
                </p>
              </div>
              <div className="font-semibold text-primary text-sm">+{disposal.points} pts</div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }
  
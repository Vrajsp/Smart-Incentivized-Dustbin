'use client';

import { useState } from 'react';
import { binFillSuggestion } from '@/ai/flows/bin-fill-suggestion';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import type { Bin } from '@/lib/types';
import { Lightbulb, Sparkles, Loader2 } from 'lucide-react';

export function AiSuggestionCard({ bins }: { bins: Bin[] }) {
  const [suggestion, setSuggestion] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSuggest = async () => {
    setIsLoading(true);
    setSuggestion('');
    try {
      const binLevels = bins.map((b) => b.fillLevel);
      const result = await binFillSuggestion({
        binLevels,
        campusMap: 'Rajarambapu Institute of Technology campus layout. Bins are located at Main Canteen, Library, Hostels, Workshop, Sports Complex, and Admin Building.',
      });
      setSuggestion(result.suggestion);
    } catch (error) {
      console.error('Failed to get AI suggestion:', error);
      setSuggestion(
        'Sorry, there was an error generating a suggestion. Please try again later.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-primary" />
          <span>Generative Fill Suggestion</span>
        </CardTitle>
        <CardDescription>
          Use AI to find the optimal waste distribution strategy.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <Button onClick={handleSuggest} disabled={isLoading}>
          {isLoading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Sparkles className="mr-2 h-4 w-4" />
          )}
          {isLoading ? 'Generating...' : 'Get Suggestion'}
        </Button>
        {(isLoading || suggestion) && (
            <div className='relative'>
                <Textarea
                    placeholder="AI suggestion will appear here..."
                    value={suggestion}
                    readOnly
                    rows={8}
                    className="bg-secondary"
                />
                {isLoading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-background/50 backdrop-blur-sm">
                        <Loader2 className="h-8 w-8 animate-spin text-primary"/>
                    </div>
                )}
            </div>
        )}
      </CardContent>
    </Card>
  );
}
